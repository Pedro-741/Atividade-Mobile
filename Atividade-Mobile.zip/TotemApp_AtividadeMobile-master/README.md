# TotemApp_AtividadeMobile
App desenvolvido em Ionic e Angular conforme a lista de exercicios para a disciplina de Desenvolvimento de Aplicações para Dispositivos Móveis.
